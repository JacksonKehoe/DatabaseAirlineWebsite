<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: #d96459;
		font-family: monospace;
		font-size: 25px;
		text-align: left;
	}
	th{
		background-color: #d96459;
		color: white;
	}
	tr:nth-child(even) {background-color: #f2f2f2}
	</style>
</head>
<body>

<?php
$result = $conn->query("select * from flight");

while ($row = $result->fetch()) {
echo"<tr><td>{$row['FlightNumber']}</td><td>{$row['FlightEstimatedArrv']}</td></tr>";
} 
echo"</table>";
?>
</body>
</html>