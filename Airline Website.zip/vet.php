<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Vet Clinic</title>
</head>
<body>
    <h1>Welcome to the Vet Clinic</h1>
    <h2>Pets we look after</h2>
    <ol>
        <li>Dogs</li>
        <li>Cats</li>
        <li>Guinea Pigs</li>
       <li>Birds</li>
    </ol>
</body>
</html>