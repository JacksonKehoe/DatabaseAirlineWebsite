<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: #d96459;
		font-family: monospace;
		font-size: 25px;
		text-align: left;
	}
	th{
		background-color: #d96459;
		color: white;
	}
	tr:nth-child(even) {background-color: #f2f2f2}
	</style>
</head>
<body>

<?php
/* add airplane type and store everything in flight */
$result = $conn->query("select * from flight INNER JOIN flightday ON FlightNumber = DayFlightNumber INNER JOIN airline ON FlightAirlineCode = AirlineCode ORDER BY FlightNumber");

while ($row = $result->fetch()) {
echo"<tr><td>{$row['FlightNumber']}</td><td>{$row['AirlineName']}</td><td>{$row['FlightAirplaneID']}</td><td>{$row['FlightArrvAirportCode']}</td><td>{$row['FlightDeptAirportCode']}</td><td>{$row['Day']}</td></tr>";
} 
echo"</table>";
?>
<div style="padding-left:16px">
  <h2>Add a new Flight:</h2>
<form action="" method="post">
  <label for="Airline">Choose an Airline:</label>
  <select name="Airline" id="Airline">
    <option value="001">American Airlines INC.</option>
    <option value="014">Air Canada</option>
    <option value="017">Emirates Airlines</option>
  </select>
  <br><br>
  <label for="DeptAirport">Choose a Departure Airport:</label>
  <select name="DeptAirport" id="DeptAirport">
    <option value="HND">HND</option>
    <option value="JFK">JFK</option>
    <option value="LAX">LAX</option>
	<option value="LXU">LXU</option>
    <option value="PEK">PEK</option>
    <option value="YYZ">YYZ</option>
  </select>
  <br><br>
  <label for="ArrvAirport">Choose an Arrival Airport:</label>
  <select name="ArrvAirport" id="ArrvAirport">
    <option value="HND">HND</option>
    <option value="JFK">JFK</option>
    <option value="LAX">LAX</option>
	<option value="LXU">LXU</option>
    <option value="PEK">PEK</option>
    <option value="YYZ">YYZ</option>
  </select>
  <br><br>
  <label for="AirplaneID">Input Airplane ID:</label>
  <select name="AirplaneID" id="AirplaneID">
<?php
$query = "Select AirplaneID from airplane GROUP BY AirplaneID";
	$result = $conn->query($query);
	while($row = $result->fetch()){
		echo "<option value = '".$row['AirplaneID']."'>".$row['AirplaneID']."</option>";
}
?>
  </select>
  <br><br>
  <label for="FlightNum">Input Flight Number:</label>
  <input type="text" id="FlightNum" name="FlightNum">
  <br><br>
  <label for="DayOff">Choose Offered Day:</label>
  <select name="DayOff" id="DayOff">
    <option value="Monday">Monday</option>
    <option value="Tuesday">Tuesday</option>
    <option value="Wednesday">Wednesday</option>
	<option value="Thursday">Thursday</option>
	<option value="Friday">Friday</option>
	<option value="Saturday">Saturday</option>
	<option value="Sunday">Sunday</option>
  </select>
  <br><br>
  <input type="submit" value="Submit">
</form>
</div>
<?php
$FlightNumber = $_POST['FlightNum'] ?? "";
$AirlineCode = $_POST['Airline'] ?? "";
$AirplaneType = $_POST['AirplaneID'] ?? "";
$FlightArrvAirportCode = $_POST['ArrvAirport'] ?? "";
$FlightDeptAirportCode = $_POST['DeptAirport'] ?? "";
$Day = $_POST['DayOff'] ?? "";
$query = "INSERT INTO flight VALUES('".$FlightNumber."','".$AirlineCode."','".$AirplaneType."','".$FlightArrvAirportCode."','".$FlightDeptAirportCode."','NULL','NULL','NULL','NULL');";
$result = $conn->query($query);
$query = "INSERT INTO flightday VALUES('".$Day."','".$FlightNumber."','".$AirlineCode."');";
$result = $conn->query($query);
/*
$stmt = $conn->prepare("INSERT INTO NewFlight(FlightNumber, AirlineName, FlightArrvAirportCode, FlightDeptAirportCode, Day) VALUES ('%s', '%s', '%s', '%s', '%s')", $FlightNumber,$AirlineName,$FlightArrvAirportCode,$FlightDeptAirpotCode,$Day);
*/

/*
$stmt->bind_param("sssss", $FlightNum, $Airline, $ArrvAirport, $DeptAirport, $DayOff);
*/
/*
while ($row = $stmt->fetch()) {
echo"<tr><td>{$row['FlightNumber']}</td><td>{$row['AirlineName']}</td><td>{$row['FlightArrvAirportCode']}</td><td>{$row['FlightDeptAirportCode']}</td><td>{$row['Day']}</td></tr>";
}
*/ 
echo"</table>";
?>
</body>
</html>