<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #1849b5;
  color: white;
}
</style>
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: #d96459;
		font-family: monospace;
		font-size: 25px;
		text-align: left;
	}
	th{
		background-color: #d96459;
		color: white;
	}
	tr:nth-child(even) {background-color: #f2f2f2}
	</style>
</head>
<body>
<?php include 'connectdb.php';?>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
<div class="topnav">
  <a href="Airline.html">Airline</a>
  <a class="active" href="Arrivals.php">Arrivals</a>
  <a href="Booking.php">Booking</a>
  <a href="NewFlight.php">NewFlight</a>
  <a href="UpdateTime.php">UpdateTime</a>
  <a href="Availability.php">Availability</a>
  <a href="About.html">About</a>
</div>
<div id="container">
   <h2>Arriving Flights</h2>
  <table>
	<tr>
	<th>Flight Code</th>
	<th>Arrival Time</th>
	</tr>
<?php include 'getarrivals.php';?>
</table>
</div>
</body>
</html>