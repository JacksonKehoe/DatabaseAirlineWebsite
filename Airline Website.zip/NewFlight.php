<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  margin: 0;
  font-family: Arial, Helvetica, sans-serif;
}

.topnav {
  overflow: hidden;
  background-color: #333;
}

.topnav a {
  float: left;
  color: #f2f2f2;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
  font-size: 17px;
}

.topnav a:hover {
  background-color: #ddd;
  color: black;
}

.topnav a.active {
  background-color: #1849b5;
  color: white;
}
/*-------------*/
* {
  box-sizing: border-box;
}

body {
  font-family: Arial, Helvetica, sans-serif;
}

/* Style the header */
header {
  background-image: url('airlinebackground.jpg');
  background-size: 100% 100%;
  padding: 30px;
  text-align: center;
  font-size: 35px;
  color: black;
  margin-top: 48px;
}

/* Create two columns/boxes that floats next to each other */
nav {
  float: left;
  width: 30%;
  height: 300px; /* only for demonstration, should be removed */
  background: #666699;
  padding: 10px;
}

/* Style the list inside the menu */
nav ul {
  list-style-type: none;
  padding: 0;
}

article {
  float: left;
  padding: 20px;
  width: 70%;
  background-color: #f1f1f1;
  height: 300px; /* only for demonstration, should be removed */
}

/* Clear floats after the columns */
section::after {
  content: "";
  display: table;
  clear: both;
}

/* Style the footer */
footer {
  background-color: #777;
  padding: 10px;
  text-align: center;
  color: white;
}
@media (max-width: 600px) {
  nav, article {
    width: 100%;
    height: auto;
  }
}
.center {
  display: block;
  margin-left: auto;
  margin-right: auto;
  width: 50%;
}

</style>
</head>
<body>
<?php include 'connectdb.php';?>
        <link href="css/bootstrap.min.css" rel="stylesheet">
        <link href="css/style.css" rel="stylesheet">
<div class="topnav">
  <a href="Airline.html">Airline</a>
  <a href="Arrivals.php">Arrivals</a>
  <a href="Booking.php">Booking</a>
  <a class="active" href="NewFlight.php">NewFlight</a>
  <a href="UpdateTime.php">UpdateTime</a>
  <a href="Availability.php">Availability</a>
  <a href="About.html">About</a>
</div>

<div id="container">
   <h2>Flights Offered</h2>
  <table>
	<tr>
	<th>Flight Code</th>
	<th>Airline</th>
	<th>Airplane Type</th>
	<th>Arrival Airport</th>
	<th>Departure Airport</th>
	<th>Day</th>
	</tr>
<?php include 'getnewflight.php';?>
</table>
</div>
<footer>
<p>Refresh page to show updated table</p>
</footer>
</body>
</html>