<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: #d96459;
		font-family: monospace;
		font-size: 25px;
		text-align: left;
	}
	th{
		background-color: #d96459;
		color: white;
	}
	tr:nth-child(even) {background-color: #f2f2f2}
	</style>
</head>
<body>
<div style="padding-left:16px">
  <h2>Availability of Seats Dependent on Day</h2>
<form action="" method="post">
  <label for="DayAv">Choose Day of the Week:</label>
  <select name="DayAv" id="DayAv">
    <option value="Monday">Monday</option>
    <option value="Tuesday">Tuesday</option>
    <option value="Wednesday">Wednesday</option>
	<option value="Thursday">Thursday</option>
	<option value="Friday">Friday</option>
	<option value="Saturday">Saturday</option>
	<option value="Sunday">Sunday</option>
  </select>
  <input type="submit" value="Submit">
  <br><br>
</form>
</div>
<?php
$Day = $_POST['DayAv'] ?? "";
$query = "SELECT AVG(AirplaneTypeSeats) AS avgseats FROM ((flight INNER JOIN flightday ON FlightAirlineCode = DayFlightAirlineCode AND FlightNumber = DayFlightNumber) INNER JOIN airplane ON AirplaneID = FlightAirplaneID) INNER JOIN airplanetype ON DesignedAirplaneType = AirplaneTypeName WHERE Day = '".$Day."';";
$result = $conn->query($query);
$row = $result->fetch();
echo "The average seats on ".$Day." is : " .$row['avgseats'];

/*while ($row = $result->fetch()) {
echo"<tr><td>{$row['FlightNumber']}</td><td>{$row['FlightEstimatedArrv']}</td></tr>";
} 
echo"</table>";*/
?>
</body>
</html>