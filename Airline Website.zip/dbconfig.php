<?php
    $host = 'localhost';
    $dbname = 'airlinedb';
    $username = 'root';
    $password = '';
?>