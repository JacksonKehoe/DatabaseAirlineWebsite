<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: #d96459;
		font-family: monospace;
		font-size: 25px;
		text-align: left;
	}
	th{
		background-color: #d96459;
		color: white;
	}
	tr:nth-child(even) {background-color: #f2f2f2}
	</style>
</head>
<body>

<?php
$result = $conn->query("select * from flight");

while ($row = $result->fetch()) {
echo"<tr><td>{$row['FlightNumber']}</td><td>{$row['FlightArrvAirportCode']}</td><td>{$row['FlightDeptAirportCode']}</td><td>{$row['FlightActualArrv']}</td><td>{$row['FlightEstimatedArrv']}</td>
<td>{$row['FlightActualDept']}</td><td>{$row['FlightEstimatedDept']}</td></tr>";
} 
echo"</table>";
?>
<!--
<?php
$query = "Select FlightNumber from flight";
	$result = $conn->query($query);
	while($row = $result->fetch()){
		echo "<option value = '".$row['FlightNumber']."'>".$row['FlightNumber']."</option>";
}
?>
-->
<div style="padding-left:16px">
  <h2>Update Actual Departure Time:</h2>
<form action="" method="post">
  <label for="FlightCode">Choose a Flight:</label>
  <select name="FlightCode" id="FlightCode">
<?php
$query = "Select FlightNumber from flight GROUP BY FlightNumber";
	$result = $conn->query($query);
	while($row = $result->fetch()){
		echo "<option value = '".$row['FlightNumber']."'>".$row['FlightNumber']."</option>";
}
?>
  </select>
  <br><br>
   <label for="DeptTime">Enter new departure time in format (yyyy-mm-dd hh:mm:ss):</label>
  <input type="text" id="DeptTime" name="DeptTime">
  <br><br>
  <input type="submit" value="Submit">
</form>
</div>
<?php
$FlightCode = $_POST['FlightCode'] ?? "";
$DeptTime = $_POST['DeptTime'] ?? "";
$query = "UPDATE flight SET FlightActualDept = '".$DeptTime."' WHERE FlightNumber = '".$FlightCode."'"; 
$result = $conn->query($query);
echo"</table>";
?>
</body>
</html>