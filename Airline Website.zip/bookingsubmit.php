<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: #d96459;
		font-family: monospace;
		font-size: 25px;
		text-align: left;
	}
	th{
		background-color: #d96459;
		color: white;
	}
	tr:nth-child(even) {background-color: #f2f2f2}
	</style>
</head>
<body>
<h2>Available Flights associated with Airline and Day:</h2>
</body>
<div id="container">
  <table>
	<tr>
	<th>Flight Code</th>
	<th>Departing City</th>
	<th>Arriving City</th>
	</tr>
	<!-- include php file -->
	<!-- php file will need to use input from form on booking.php to output Flight Code, Departing City and Arriving City in table format-->
</table>
</div>
</html>