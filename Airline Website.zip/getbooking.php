<!DOCTYPE html>
<html>
<head>
<style type="text/css">
	table{
		border-collapse: collapse;
		width: 100%;
		color: #d96459;
		font-family: monospace;
		font-size: 25px;
		text-align: left;
	}
	th{
		background-color: #d96459;
		color: white;
	}
	tr:nth-child(even) {background-color: #f2f2f2}
	</style>
</head>
<body>

<?php
$result = $conn->query("select * from flight INNER JOIN flightday ON FlightNumber = DayFlightNumber INNER JOIN airline ON FlightAirlineCode = AirlineCode ORDER BY FlightNumber");

while ($row = $result->fetch()) {
echo"<tr><td>{$row['FlightNumber']}</td><td>{$row['AirlineName']}</td><td>{$row['FlightAirplaneID']}</td><td>{$row['FlightArrvAirportCode']}</td><td>{$row['FlightDeptAirportCode']}</td><td>{$row['Day']}</td></tr>";
} 
echo"</table>";

?>
<div style="padding-left:16px">
<h2>Input Airline Code and Day</h2>
<form action="" method="post">
  <label for="Airline">Choose an Airline Code:</label>
  <select name="Airline" id="Airline">
    <option value="001">001</option>
    <option value="014">014</option>
    <option value="017">017</option>
  </select>
  <br><br>
    <label for="DayOff">Choose Offered Day:</label>
  <select name="DayOff" id="DayOff">
    <option value="Monday">Monday</option>
    <option value="Tuesday">Tuesday</option>
    <option value="Wednesday">Wednesday</option>
	<option value="Thursday">Thursday</option>
	<option value="Friday">Friday</option>
	<option value="Saturday">Saturday</option>
	<option value="Sunday">Sunday</option>
  </select>
  <br><br>
  <input type="submit" value="Submit">
</form> 
</div>
<?php
$Airline = $_POST['Airline'] ?? "";
$Day = $_POST['DayOff'] ?? "";
$query = "SELECT FlightNumber, FlightAirlineCode, a1.AirportCity as FlightDeptAirportCode, a2.Airportcity as FlightArrvAirportCode FROM ((flight INNER JOIN flightday ON FlightAirlineCode = DayFlightAirlineCode AND FlightNumber = DayFlightNumber) INNER JOIN airport a1 ON a1.AirportCode = FlightDeptAirportCode) INNER JOIN airport a2 ON a2.AirportCode = FlightArrvAirportCode WHERE FlightAirlineCode = '". $Airline ."' AND Day = '". $Day ."'" ;
$result=$conn->query($query);
while($row = $result->fetch()){
	echo "Flight Code:".$row["FlightNumber"]."<br>";
	echo "From " .$row["FlightDeptAirportCode"]. " to ".$row["FlightArrvAirportCode"]. "<br>"."<br>";
}
/*
$Airline = $_POST['Airline'] ?? "";
$Day = $_POST['DayOff'] ?? "";
$query = "INSERT INTO flight VALUES('".$FlightNumber."','".$AirlineCode."','".$AirplaneType."','".$FlightArrvAirportCode."','".$FlightDeptAirportCode."','NULL','NULL','NULL','NULL');";
$result = $conn->query($query);
echo"</table>";
*/
?>
</body>
</html>